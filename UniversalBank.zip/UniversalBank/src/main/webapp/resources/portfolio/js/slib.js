/**
 * Created by schandramouli on 10/3/15.
 */

//Object.prototype.tS = function() { return this.toString(); };
var f = Math.floor;
var r = Math.random;
